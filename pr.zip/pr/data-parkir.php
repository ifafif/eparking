<?php include 'header.php'  ?>
<?php include 'menu.php'  ?>

        <!-- Begin Page Content -->
        <div class="container-fluid">


          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Log Parkir</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Nomor kartu</th>
                      <th>Pemilik Kendaraan</th>
                      <th>Nomor Kendaran</th>
                      <th>Jenis Kendaraan</th>
                      <th>Tanggal</th>
                      <th>Waktu Masuk</th>
                      <th>Waktu Keluar</th>
                    </tr>
                  </thead>

                  <tbody>
                    <tr>
                      <td>078291212</td>
                      <td>Muhammad Afif Aminulyo</td>
                      <td>W 2265 PJ</td>
                      <td>Motor</td>
                      <td>20 November 2019</td>
                      <td>07.21</td>
                      <td>18.01</td>
                    </tr>
                    <tr>
                      <td>029832812</td>
                      <td>Ade Yuni Trianto</td>
                      <td>B 1221 PJ</td>
                      <td>Mobil</td>
                      <td>20 November 2019</td>
                      <td>07.21</td>
                      <td> </td>
                      </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->



  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  
<?php include 'footer.php'  ?>
