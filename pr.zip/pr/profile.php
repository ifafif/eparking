<?php include 'header.php'  ?>
<?php include 'menu.php'  ?>

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Profile User</h6>
            </div>
            <div class="card-body">
                <form>
                    <div class="form-row">
                            <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">NPK*</label>
                                    <input type="number" requiered class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Contoh : 71821">
                              </div>
                              <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">Nama User*</label>
                                    <input type="text" requiered class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Contoh : Eko">
                              </div>
                              <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">Email</label>
                                    <input type="email"  class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Contoh : eko@astragraphia.co.id">
                              </div>
                              
                              <div class="form-group col-md-6">
                                        <label for="exampleInputPassword1">Rules User*</label>
                                        <select class="form-control" required selected="Petugas / Admin">
                                                <option>Petugas / Admin</option>
                                                <option>Superadmin</option>
                                        </select>
                              </div>
                    </div>           
                                <br>
                                <a href="#" class="btn btn-primary btn-icon-split">
                                        <span class="icon text-primary-600">
                                            <i class="fas fa-check"></i>
                                        </span>
                                        <span class="text">Simpan Data</span>
                                </a>

                  </form>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->


  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <?php include 'footer.php'  ?>
