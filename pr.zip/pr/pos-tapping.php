<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>
    E-Parking Astragraphia
  </title>
  <!-- Favicon -->
  <link href="assets/img/brand/favicon.png" rel="icon" type="image/png">
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  <link href="assets/js/plugins/nucleo/css/nucleo.css" rel="stylesheet" />
  <link href="assets/js/plugins/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet" />
  <!-- CSS Files -->
  <link href="assets/css/argon-dashboard.css?v=1.1.0" rel="stylesheet" />
</head>

<body class="">

  <div class="main-content">
    <!-- Header -->
    <div class="header pb-8 pt-5 pt-lg-8  align-items-center" style="min-height: 435px; background-image: url(assets/img/ag.jpg); background-size: cover; background-position: center top; margin-top: -100px">
      <!-- Mask -->
      <span class="mask bg-gradient-default opacity-8"></span>
      <!-- Header container -->
      <div class="container-fluid align-items-center">
        <div class="row">
          <div class="col-lg-8">
            
            <h1 class="display-2 text-white">Selamat Datang</h1>
            <p class="text-white mt-0 mb-4">Silahkan melakukan tapping untuk parkir di lingkungan astragraphia</p>
            <h4 class="display-5 text-white" style="margin-bottom:1rem !important">Bertugas Hari ini : Eko </h4>
            <!-- <hr style="background:#848484"> -->
          </div>
          <div class="col-lg-4">
            <div class="card card-profile shadow">
                    <div class="card-body pt-0 pt-md-4">
                        <div class="">
                            <i class="fa fa-calendar text-info"></i><span>&nbsp;&nbsp; Tanggal Hari Ini :  07 November 2019</span>
                            <hr class="my-3">
                            <i class="fa fa-clock text-info"></i><span> <span>&nbsp; Waktu Sekarang :  07.38</span>
                        </div>
                    </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--7">
      <div class="row">
        <div class="col-xl-4 order-xl-2 mb-5 mb-xl-0">
          <div class="card card-profile shadow">
            <div class="card-body pt-0 pt-md-4">
              <div>
               <div class="text-center">
                <h3>
                  <h2>Detail Data Kartu</h2>
                </h3>
                <div class="h5 font-weight-300">
                  <i class="ni location_pin mr-2"></i>Nomor Kartu : 07863512
                </div>
                 </div>
                <!-- <div class="h5 mt-4">
                  <i class="ni business_briefcase-24 mr-2"></i>Solution Manager - Creative Tim Officer
                </div>
                <div>
                  <i class="ni education_hat mr-2"></i>University of Computer Science
                </div> -->
                <hr class="my-3" />
                <!-- <i style="text-align: left;" class="ni ni-single-02 text-blue" ></i><p> Jenis Kendaraan : Motor</p> -->
                <!-- <i class="fa fa-calendar text-info"></i><span > Jenis Kendaraan</span> -->
                <p class="text-black " style="text-align: left;">Jenis Kendaraan : Motor </p>
                <p class="text-black " style="text-align: left;">Plat Nomor Kendaraan : B 2712 CKS </p>
                <p class="text-black " style="text-align: left;">Jam Masuk : 07.38 </p>
                
              </div>
            </div>
          </div>
        </div>
        <div class="col-xl-8 order-xl-1">
          <div class="card bg-secondary shadow">
            <div class="card-header bg-white border-0">
              <div class="row align-items-center">
                 <div class="col-4">              
                    <div class="col-auto">
                        <div class="icon icon-shape bg-info text-white rounded-circle shadow">
                            <i class="ni ni-badge"></i>
                       </div>
                   </div>
                 </div>
                <div class="col-8">
                  <h3 style="font-size: 25px;"> Tapping Kartu Anda</h3>
                </div>

              </div>
            </div>
            <div class="card-body">
                <form role="form">
                        <div class="form-group mb-3">
                          <div class="input-group input-group-alternative" style="margin-top:20px">
                            <div class="input-group-prepend">
                              <!-- <span class="input-group-text"></span> -->
                            </div>
                            <input class="form-control" placeholder="Nomor Kartu Anda" style="height:100px; font-size:25px; text-align: center;" type="text">
                          </div>
                        </div>
                 </form>
            </div>
          </div>
        </div>
      </div>
      <!-- Footer -->
      <footer class="footer">
        <div class="row align-items-center justify-content-xl-between">
          <div class="col-xl-6">
            <div class="copyright text-center text-xl-left text-muted">
              &copy; 2018 <a href="https://www.creative-tim.com" class="font-weight-bold ml-1" target="_blank">Astragraphia</a>
            </div>
          </div>
          <div class="col-xl-6">
            <ul class="nav nav-footer justify-content-center justify-content-xl-end">
              <!-- <li class="nav-item">
                <a href="https://www.astragraphia.co.id/" class="nav-link" target="_blank">Astragraphia</a>
              </li> -->
            </ul>
          </div>
        </div>
      </footer>
    </div>
  </div>
  <!--   Core   -->
  <script src="assets/js/plugins/jquery/dist/jquery.min.js"></script>
  <script src="assets/js/plugins/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <!--   Optional JS   -->
  <!--   Argon JS   -->
  <script src="assets/js/argon-dashboard.min.js?v=1.1.0"></script>
  <script src="https://cdn.trackjs.com/agent/v3/latest/t.js"></script>
  <script>
    window.TrackJS &&
      TrackJS.install({
        token: "ee6fab19c5a04ac1a32a645abde4613a",
        application: "argon-dashboard-free"
      });
  </script>
</body>

</html>