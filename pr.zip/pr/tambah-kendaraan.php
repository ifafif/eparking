<?php include 'header.php'  ?>
<?php include 'menu.php'  ?>

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Tambah Kendaraan</h6>
            </div>
            <div class="card-body">
                <form>
                    <div class="form-row">
                            <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">Nomor Kendaraan*</label>
                                    <input type="number" requiered class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Contoh : B 8271 JSK">
                              </div>
                              <div class="form-group col-md-6">
                                        <label for="exampleInputPassword1">Jenis Kendaraan*</label>
                                        <select class="form-control" requiered>
                                                <option>Motor</option>
                                                <option>Mobil</option>
                                        </select>
                              </div> 
                    </div>           
                    <hr>
                    <div class="form-row">
                              <div class="form-group col-md-6">
                                    <label for="exampleInputPassword1">Nomor Kartu*</label>
                                    <input type="number"  value="" requiered class="form-control" id="exampleInputPassword1" placeholder="Contoh : 08271281">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="exampleInputPassword1">Pemilik Kendaraan*</label>
                                    <input type="text"  value=""  requiered class="form-control" id="exampleInputPassword1" placeholder="Contoh : Muhammad Afif Aminulyo">
                                  </div>
                                  <div class="form-group col-md-6">
                                        <label for="exampleInputPassword1">NPK</label>
                                        <input type="number"  value=""  class="form-control" id="exampleInputPassword1" placeholder="Contoh : 3312">
                                  </div>
                                  <div class="form-group col-md-6">
                                        <label for="exampleInputPassword1">Extension / Lantai Pemilik</label>
                                        <input type="text"  value="" requiered class="form-control" id="exampleInputPassword1" placeholder="Contoh : 1040 atau Lantai 4 Depan">
                                  </div>

              
                                </div>
                                <br>
                                <a href="#" class="btn btn-primary btn-icon-split">
                                        <span class="icon text-primary-600">
                                            <i class="fas fa-check"></i>
                                        </span>
                                        <span class="text">Simpan Data</span>
                                </a>

                  </form>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->


  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>



  <?php include 'footer.php'  ?>
