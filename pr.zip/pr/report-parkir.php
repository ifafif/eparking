<?php include 'header.php'  ?>
<?php include 'menu.php'  ?>

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Repor Parkir</h6>
            </div>
            <div class="card-body">
                <form>
                    <div class="form-row">
                                  <div class="form-group col-md-6">
                                    <label for="exampleInputPassword1">Tanggal Awal Report</label>
                                    <input type="date" required class="form-control" id="exampleInputPassword1" placeholder="Contoh : 3312">
                                  </div>
                                  <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">Tanggal Akhir Report</label>
                                    <input type="date" required class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Contoh : Eko">
                                  </div>
              
                                </div>
                                <a href="#" class="btn btn-primary btn-icon-split">
                                        <span class="icon text-primary-600">
                                            <i class="fas fa-archive"></i>
                                        </span>
                                        <span class="text">Tarik Report</span>
                                </a>

                  </form>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>


<?php include 'footer.php'  ?>