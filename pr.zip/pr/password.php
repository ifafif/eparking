<?php include 'header.php'  ?>
<?php include 'menu.php'  ?>

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Ubah Password</h6>
            </div>
            <div class="card-body">
                <form>
                    <div class="form-row">
                            <div class="form-group col-md-4">
                                    <label for="exampleInputEmail1">Password Lama*</label>
                                    <input type="password" requiered class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Contoh : 12345">
                              </div>
                              <div class="form-group col-md-4">
                                    <label for="exampleInputEmail1">Password Baru*</label>
                                    <input type="password" requiered class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Contoh : Pass12345">
                              </div>
                              <div class="form-group col-md-4">
                                    <label for="exampleInputEmail1">Konfirmasi Password*</label>
                                    <input type="password" requiered  class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Contoh : Pass12345">
                              </div>
                              <span>*Harap ingat baik-baik password baru anda</span>
                              
                    </div>           
                                <br>
                                <a href="#" class="btn btn-primary btn-icon-split">
                                        <span class="icon text-primary-600">
                                            <i class="fas fa-check"></i>
                                        </span>
                                        <span class="text">Ubah Password</span>
                                </a>

                  </form>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->


  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>


  <?php include 'footer.php'  ?>
